# panel_force_graph
A Panel-based graph visualization &amp; editor tool


## todo:
- [ ] migrate off of loguru for logging (to reduce imports)
- [ ] pairing state between js & python
- [ ] state editor for links/edges
- [x] coloring/width value specification
- [ ] editing simulation params (force, link length, etc)
- [ ] create panel issue on panel-convert with panel >1.5.0 